# ui
Todo lo relacionado con la interfaz de usuario.
- screens: Pantallas principales de la app.
- widgets: Componentes reutilizables.
- providers: Gesti�n de estado y l�gica de UI.
