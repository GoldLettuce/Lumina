# widgets
Componentes reutilizables de interfaz (por ejemplo, botones personalizados, tarjetas, etc.).
