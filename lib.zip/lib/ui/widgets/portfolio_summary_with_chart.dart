import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/chart_value_provider.dart';

class PortfolioSummaryWithChart extends StatefulWidget {
  const PortfolioSummaryWithChart({super.key});

  @override
  State<PortfolioSummaryWithChart> createState() => _PortfolioSummaryWithChartState();
}

class _PortfolioSummaryWithChartState extends State<PortfolioSummaryWithChart> {
  final List<Map<String, dynamic>> data = [
    {'fecha': DateTime(2025, 1, 1), 'valor': 1000.0},
    {'fecha': DateTime(2025, 2, 1), 'valor': 1200.0},
    {'fecha': DateTime(2025, 3, 1), 'valor': 1400.0},
    {'fecha': DateTime(2025, 4, 1), 'valor': 1350.0},
    {'fecha': DateTime(2025, 5, 1), 'valor': 1600.0},
  ];

  @override
  Widget build(BuildContext context) {
    final List<FlSpot> spots = data.asMap().entries.map((entry) {
      return FlSpot(entry.key.toDouble(), entry.value['valor']);
    }).toList();

    final chartProvider = context.read<ChartValueProvider>();

    return SizedBox(
      height: 200,
      child: LineChart(
        LineChartData(
          swapAnimationDuration: const Duration(milliseconds: 600),
          swapAnimationCurve: Curves.easeInOut,
          lineTouchData: LineTouchData(
            enabled: true,
            touchTooltipData: LineTouchTooltipData(
              tooltipBackgroundColor: Colors.transparent,
              tooltipPadding: EdgeInsets.zero,
              tooltipMargin: 8,
              getTooltipItems: (touchedSpots) =>
                  touchedSpots.map((_) => null).toList(),
            ),
            touchCallback: (event, response) {
              if (event is FlTapUpEvent || event is FlLongPressEnd || event is FlPanEndEvent) {
                chartProvider.limpiar();
              } else if (response != null && response.lineBarSpots != null) {
                final index = response.lineBarSpots!.first.spotIndex;
                final valor = data[index]['valor'] as double;
                chartProvider.actualizarValor(valor);
              }
            },
            handleBuiltInTouches: true,
          ),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              isStrokeCapRound: true,
              color: Theme.of(context).colorScheme.primary,
              barWidth: 2,
              isStepLineChart: false,
              dotData: FlDotData(show: false),
              belowBarData: BarAreaData(show: false),
            ),
          ],
          minX: 0,
          maxX: (data.length - 1).toDouble(),
          minY: data.map((e) => e['valor'] as double).reduce((a, b) => a < b ? a : b) * 0.95,
          maxY: data.map((e) => e['valor'] as double).reduce((a, b) => a > b ? a : b) * 1.05,
          titlesData: FlTitlesData(show: false),
          gridData: FlGridData(show: false),
          borderData: FlBorderData(show: false),
        ),
      ),
    );
  }
}
