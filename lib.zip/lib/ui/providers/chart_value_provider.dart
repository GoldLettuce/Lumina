// lib/ui/providers/chart_value_provider.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:lumina/core/chart_range.dart';
import 'package:lumina/core/point.dart';
import 'package:lumina/data/repositories_impl/price_repository_impl.dart';
import 'package:lumina/data/repositories_impl/history_repository_impl.dart';
import 'package:lumina/domain/entities/investment.dart';
import 'package:lumina/domain/repositories/price_repository.dart';
import 'package:lumina/domain/repositories/history_repository.dart';

class ChartValueProvider extends ChangeNotifier {
  final PriceRepository _priceRepository = PriceRepositoryImpl();
  final HistoryRepository _historyRepository = HistoryRepositoryImpl();

  final Set<String> _visibleSymbols = {};
  final Map<String, double> _spotPrices = {};

  Timer? _timer;

  final ChartRange _range = ChartRange.all;
  List<Point> _history = [];

  ChartRange get range => _range;
  List<Point> get history => _history;

  ChartValueProvider() {
    _startAutoRefresh();
  }

  void _startAutoRefresh() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 60), (_) {
      updatePrices();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void setVisibleSymbols(Set<String> symbols) {
    _visibleSymbols
      ..clear()
      ..addAll(symbols);
    debugPrint('🟡 setVisibleSymbols() -> $_visibleSymbols');
    updatePrices();
  }

  Future<void> updatePrices() async {
    debugPrint('🟡 updatePrices() llamado con símbolos: $_visibleSymbols');
    try {
      final prices =
      await _priceRepository.getPrices(_visibleSymbols, currency: 'USD');
      _spotPrices
        ..clear()
        ..addAll(prices);
      debugPrint('🟢 Precios recibidos desde CryptoCompare: $_spotPrices');
      notifyListeners();
    } catch (e) {
      debugPrint('❌ Error al actualizar precios: $e');
    }
  }

  double? getPriceFor(String symbol) => _spotPrices[symbol];

  Future<void> loadHistory(List<Investment> investments) async {
    try {
      final local = await _historyRepository.getHistory(
        range: ChartRange.all,
        investments: investments,
      );
      if (local.isNotEmpty) {
        _history = local;
        notifyListeners();
      }

      final updated = await _historyRepository.downloadAndStoreIfNeeded(
        range: ChartRange.all,
        investments: investments,
      );
      if (updated.isNotEmpty) {
        _history = updated;
        notifyListeners();
      }

      setVisibleSymbols(investments.map((inv) => inv.symbol).toSet());
    } catch (e) {
      debugPrint('❌ Error al cargar histórico: $e');
    }
  }
}
