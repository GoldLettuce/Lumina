# screens
Pantallas principales de la aplicaci�n (por ejemplo: HomeScreen, PortfolioScreen, etc.).
