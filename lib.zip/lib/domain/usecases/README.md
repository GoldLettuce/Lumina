# usecases
Aqu� se define la l�gica para cada acci�n relevante del negocio (casos de uso, por ejemplo: a�adir inversi�n, calcular rentabilidad, etc.).
