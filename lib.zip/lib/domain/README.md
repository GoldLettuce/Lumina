# domain
Aqu� vive la l�gica de negocio, las entidades principales, casos de uso y definiciones abstractas de los repositorios.
- entities: Definici�n de las entidades de negocio (Investment, Portfolio, etc.).
- repositories: Definici�n abstracta de repositorios.
- usecases: L�gica que define las acciones principales del negocio.
