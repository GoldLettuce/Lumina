# entities
Definici�n de las entidades principales de la l�gica de negocio (por ejemplo, Investment, Portfolio, etc.).
