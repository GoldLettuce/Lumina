# repositories
Definici�n abstracta de los repositorios (interfaces que usa la l�gica de negocio).
