import 'package:lumina/ui/providers/chart_value_provider.dart';
import 'package:lumina/core/chart_range.dart';


/// Punto del gráfico (fecha + valor)
class Point {
  final DateTime time;
  final double value;

  Point(this.time, this.value);
}

abstract class HistoryRepository {
  /// Si assetId es null → devuelve el histórico del portafolio completo
  Future<List<Point>> getHistory({
    required ChartRange range,
    String? assetId,
  });
}
