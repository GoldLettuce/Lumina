# l10n
Archivos de internacionalizaci�n (traducci�n de la app), si se necesita.
