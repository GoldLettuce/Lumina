// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Spanish Castilian (`es`).
class AppLocalizationsEs extends AppLocalizations {
  AppLocalizationsEs([String locale = 'es']) : super(locale);

  @override
  String get appTitle => 'Mi Portafolio';

  @override
  String get dailyPL => 'P/G diario | 0,00 € 0.00%';

  @override
  String get openPL => 'Abrir P/G | 4,328.47 € 1.17%';

  @override
  String get graphPlaceholder => 'Marcador de gráfico';

  @override
  String get quantity => 'Cantidad';

  @override
  String get noInvestments => 'No hay inversiones';

  @override
  String get emptyPortfolioMessage => 'No tienes inversiones aún.\n¡Comienza añ,adiendo la primera!';

  @override
  String get newOperation => 'Nueva operación';

  @override
  String get assetType => 'Tipo de activo';

  @override
  String get selectAssetType => 'Seleccione un tipo';

  @override
  String get symbol => 'Símbolo';

  @override
  String get selectSymbol => 'Selecciona un símbolo';

  @override
  String get buy => 'Compra';

  @override
  String get sell => 'Venta';

  @override
  String get fieldRequired => 'Campo obligatorio';

  @override
  String get invalidQuantity => 'Cantidad inválida';

  @override
  String get unitPrice => 'Precio unitario (€)';

  @override
  String get invalidPrice => 'Precio inválido';

  @override
  String get date => 'Fecha';

  @override
  String get selectDate => 'Seleccionar fecha';

  @override
  String get cancel => 'Cancelar';

  @override
  String get save => 'Guardar';

  @override
  String get sellAll => 'Vender todo';

  @override
  String get exceedQuantity => 'Cantidad mayor que disponible';

  @override
  String get searchAsset => 'Buscar activo';

  @override
  String get notEnoughChartData => 'No hay suficientes datos para mostrar el gráfico';
}
