# core
Clases y utilidades globales que pueden ser usadas en cualquier parte de la aplicaci�n (helpers, constantes, temas, etc.).
