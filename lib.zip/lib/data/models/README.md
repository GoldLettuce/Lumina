# models
Modelos de datos para mapear la informaci�n que llega desde APIs o se guarda localmente.
