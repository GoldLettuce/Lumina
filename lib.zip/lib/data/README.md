# data
Contiene las fuentes de datos, modelos y la implementaci�n de los repositorios.
- datasources: Clases que obtienen datos de APIs o almacenamiento local.
- models: Definici�n de modelos de datos (c�mo se guardan y procesan).
- repositories_impl: Implementaci�n concreta de los repositorios (c�mo se conectan los datos con el dominio).
