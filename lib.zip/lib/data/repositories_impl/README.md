# repositories_impl
Implementaciones concretas de los repositorios definidos en domain/repositories.
