import 'package:hive/hive.dart';
import 'package:lumina/core/chart_range.dart';
import 'package:lumina/core/point.dart';
import 'package:lumina/data/models/local_history.dart';
import 'package:lumina/domain/entities/investment.dart';
import 'package:lumina/domain/repositories/history_repository.dart';

class HistoryRepositoryImpl implements HistoryRepository {
  @override
  Future<List<Point>> getHistory({
    required ChartRange range,
    required List<Investment> investments,
  }) async {
    final historyBox = await Hive.openBox<LocalHistory>('history');
    final Map<DateTime, double> totalPorDia = {};

    final rangeKey = switch (range) {
      ChartRange.day => '1D',
      ChartRange.week => '1W',
      ChartRange.month => '1M',
      ChartRange.year => '1Y',
      ChartRange.all => 'ALL',
    };

    for (final inv in investments) {
      final key = '${inv.idCoinGecko}_$rangeKey';
      final history = historyBox.get(key);

      if (history == null) continue;

      for (final point in history.points) {
        final fecha = point.time;

        // Cantidad acumulada hasta esa fecha
        final cantidad = inv.operations
            .where((op) => !op.date.isAfter(fecha))
            .fold<double>(0.0, (sum, op) => sum + op.quantity);

        final valor = point.value * cantidad;
        totalPorDia[fecha] = (totalPorDia[fecha] ?? 0) + valor;
      }
    }

    final resultado = totalPorDia.entries
        .map((e) => Point(time: e.key, value: e.value))
        .toList()
      ..sort((a, b) => a.time.compareTo(b.time));

    return resultado;
  }
}
