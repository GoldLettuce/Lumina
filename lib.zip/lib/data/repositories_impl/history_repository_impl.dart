import 'package:lumina/data/datasources/coingecko_history_service.dart';
import 'package:lumina/domain/repositories/history_repository.dart';
import 'package:lumina/ui/providers/chart_value_provider.dart';
import 'package:lumina/core/chart_range.dart';

class HistoryRepositoryImpl implements HistoryRepository {
  final CoinGeckoHistoryService _service;

  HistoryRepositoryImpl(this._service);

  @override
  Future<List<Point>> getHistory({
    required ChartRange range,
    String? assetId,
  }) {
    return _service.getHistory(range: range, assetId: assetId);
  }
}
