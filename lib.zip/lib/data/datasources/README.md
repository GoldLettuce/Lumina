# datasources
Aqu� se ubican las clases que obtienen datos desde APIs externas, bases de datos locales o almacenamiento interno.
